/* User code: This file will not be overwritten by TASTE. */

#include "dummyconsumer.h"

void dummyconsumer_startup()
{
    /* Write your initialization code here,
       but do not make any call to a required interface. */
}

void dummyconsumer_PI_rbs(const asn1SccBase_samples_RigidBodyState *IN_rbs_in)
{
    /* Write your code here! */
}

