/* User code: This file will not be overwritten by TASTE. */

#include "dummypantiltproducer.h"

void dummypantiltproducer_startup()
{
    /* Write your initialization code here,
       but do not make any call to a required interface. */
}

void dummypantiltproducer_PI_clock()
{
    /* Write your code here! */
}

