/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_dummypantiltproducer__
#define __USER_CODE_H_dummypantiltproducer__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void dummypantiltproducer_startup();

void dummypantiltproducer_PI_clock();

extern void dummypantiltproducer_RI_pan_tilt(const asn1SccBase_commands_Joints *);

#ifdef __cplusplus
}
#endif


#endif
