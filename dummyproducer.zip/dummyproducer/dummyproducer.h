/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_dummyproducer__
#define __USER_CODE_H_dummyproducer__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void dummyproducer_startup();

void dummyproducer_PI_clock();

extern void dummyproducer_RI_motion_command(const asn1SccBase_commands_Motion2D *);

#ifdef __cplusplus
}
#endif


#endif
